import React from 'react'

const Login = () => {
  return (
    <>
        <section className='login'>
          <div className='container'>
              <div className='flex'>
                  <div className='leftpart'>
                      
                  </div>
              </div>
          </div>
        </section>
        
    </>
  )
}

export default Login