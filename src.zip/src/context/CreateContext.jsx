import { createContext } from "react";

const CreatContext = createContext()
export default  CreatContext;