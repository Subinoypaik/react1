import React, { useState } from 'react'
import CreatContext from './CreateContext'

export const Provide = ({children}) => {

    const [datas, setdata] = useState(true);

    const [profile, setprofile] = useState(false);
  return (
    <CreatContext.Provider value={{datas,setdata,profile, setprofile}}>
        {children}
    </CreatContext.Provider>
  )
}
