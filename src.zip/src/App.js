import {BrowserRouter as Router,Routes,Route} from 'react-router-dom'
import Header from './component/common/Header';
import Nav from "./component/common/Nav";
import { Provide } from './context/Provide';
import Dashboard from './pages/Dashboard';


function App() {
 
  return (
    <>
    <Provide>
    
   
     <Router>
      <Header/>
      <Routes>
      <Route path='/' element={<Dashboard/>}/>
          <Route path='/dashboard' element={<Dashboard/>}/>
          
        </Routes>
      </Router>
      </Provide>
    </>
  );
}

export default App;
