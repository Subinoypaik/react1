import { useContext } from "react";

import logo from "../../assets/Images/logo.png";
import navbarIcons from "../../assets/Images/navbar.svg";
import avter from "../../assets/Images/avatar.jpg";
import arrow from "../../assets/Images/arrow.svg";
import CreatContext from "../../context/CreateContext";
const Header = () => {
  let {datas,setdata,profile, setprofile}=useContext(CreatContext)
  
    // const [datas, setdata] = useState(true);
    // const [profile, setprofile] = useState(false);
    const dropdown=()=>{
      setprofile(!profile)
    }
    const menumobile = () => {
      setdata(!datas);
    };
  return (
    <>
          <div className="topmenu flex bg-white  justify-between p-4 items-center fixed top-0 w-full">
           
              <h1 onClick={menumobile}>
                <img src={navbarIcons} alt="navbar" width={"30px"}/>
              </h1>
              <div className="logo  pl-0 w-64">
        <img src={logo} alt="logo" width={"150px"} className="m-lrft" />
      </div>
              <div className="top-right flex items-center relative ml-auto">
                <div className="avter border-solid overflow-hidden cursor-pointer flex"  onClick={dropdown} width={"30px"} height={"30px"}>
                  <img src={avter} alt="aver" width={"30px"} height={"30px"}  className="relative rounded-full  border-solid border-stone-500 cursor-pointer"/>
                  <img className="relative" width={"20px"} src={arrow} alt="dropdown"/>
                </div>
              {
                profile && 
                <div className="dropdown absolute overflow-hidden top-10  right-4 rounded">
                  <ul className="bg-white p-5">
                    <li>Profile</li>
                    <li>Setting</li>
                    <li>home</li>
                  </ul>
               </div>
              }
              </div>
            </div>
    </>
  )
}

export default Header