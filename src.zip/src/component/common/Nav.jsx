import { useContext, useState } from "react";
import LeftNav from "../common/Leftnav";
import navbarIcons from "../../assets/Images/navbar.svg";
import avter from "../../assets/Images/avatar.jpg";
import arrow from "../../assets/Images/arrow.svg";
import logo from "../../assets/Images/logo.png";
import CreatContext from "../../context/CreateContext";
const Topnav = () => {
  // const [datas, setdata] = useState(true);
  let contextData = useContext(CreatContext)
  let {datas,setdata} = contextData

  const [profile, setprofile] = useState(false);
  const dropdown=()=>{
    setprofile(!profile)
  }
  const menumobile = () => {
    setdata(!datas);
  };
  return (
    <>
         <div className="admin md:relative">
        <div className="containerBox flex">
          {
            <div
              className={` ${
                datas ? "lg:w-72 left-0 fixed" : "w-16 left-0 fixed"
              } leftnav pl-4   h-screen  bg-white `}
            >
             {/* <div className="logo  pl-0">
        <img src={logo} alt="logo" width={"150px"} className="m-lrft" />
      </div> */}
              <LeftNav data={datas} />
            </div>
          }

          
        </div>
      </div> 
    </>
  )
}

export default Topnav