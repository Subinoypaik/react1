import React from "react";
import { NavLink } from 'react-router-dom'

import home from "../../assets/Images/home.svg";
import Product from "../../assets/Images/product.svg";

const leftnav = (props) => {
  let { data } = props;
  return (
    <div>
     
      <h6 className="text-xs mb-5">Menu</h6>
      <ul>
        <li className="mt-3">
      

          <NavLink  to="/dashboard" className="flex">
            <img src={home} alt="w" width={"25px"} />
            <span className={`${!data && `hidden`} ml-3`}> Dashboard</span>
          
            </NavLink>
            
        </li>
        <li className="mt-3">
        <NavLink  to="/" className="flex">
            <img src={Product} alt="w" width={"25px"} />
            <span className={`${!data && `hidden`} ml-3`}> Product</span>
        </NavLink>

        
        </li>
      </ul>
    </div>
  );
};

export default leftnav;
